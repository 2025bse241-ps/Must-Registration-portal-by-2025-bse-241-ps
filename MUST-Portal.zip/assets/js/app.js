/* MUST Portal — shared front-end logic for the auth screens.
   Static demo: accounts live in localStorage, passwords are hashed, never stored raw. */
(function () {
  'use strict';

  var KEYS = {
    user: 'must.user',
    session: 'must.session',
    remember: 'must.remember',
    theme: 'must.theme',
    app: 'must.app'
  };

  /* --------------------------------------------------------------- utils -- */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  var store = {
    get: function (k, fallback) {
      try {
        var raw = localStorage.getItem(k);
        return raw === null ? fallback : JSON.parse(raw);
      } catch (e) { return fallback; }
    },
    set: function (k, v) {
      try { localStorage.setItem(k, JSON.stringify(v)); return true; }
      catch (e) { return false; }
    },
    del: function (k) { try { localStorage.removeItem(k); } catch (e) {} }
  };

  var $prev = null;
  function toast(title, message, kind) {
    var host = $('#toasts');
    if (!host) {
      host = document.createElement('div');
      host.id = 'toasts';
      host.className = 'toasts';
      host.setAttribute('role', 'status');
      host.setAttribute('aria-live', 'polite');
      document.body.appendChild(host);
    }
    var icon = kind === 'ok' ? 'check-circle' : kind === 'warn' ? 'alert-circle' : 'info';
    var el = document.createElement('div');
    el.className = 'toast toast--' + (kind || 'info');
    el.innerHTML =
      '<svg aria-hidden="true"><use href="#i-' + icon + '"></use></svg>' +
      '<div><b></b><span></span></div>';
    el.querySelector('b').textContent = title;
    el.querySelector('span').textContent = message || '';
    host.appendChild(el);
    $prev = el;
    setTimeout(function () {
      el.classList.add('is-out');
      setTimeout(function () { el.remove(); }, 260);
    }, 4200);
  }

  /* --------------------------------------------------------------- theme -- */
  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme === 'dark' ? 'dark' : 'light');
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'dark' ? '#0B0F1E' : '#F5F1E7');
  }
  function initTheme() {
    var saved = store.get(KEYS.theme, null);
    if (!saved) {
      saved = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    applyTheme(saved);
  }
  function toggleTheme() {
    var next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    store.set(KEYS.theme, next);
    applyTheme(next);
    return next;
  }
  initTheme();

  /* ----------------------------------------------------------- validation -- */
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i;

  function setFieldError(input, message) {
    var field = input.closest('.field');
    if (!field) return;
    if (message) {
      field.classList.add('has-error');
      var err = field.querySelector('.field-error span');
      if (err) err.textContent = message;
      input.setAttribute('aria-invalid', 'true');
    } else {
      field.classList.remove('has-error');
      input.removeAttribute('aria-invalid');
    }
  }
  function clearFieldErrors(scope) {
    $$('.field.has-error', scope).forEach(function (f) {
      f.classList.remove('has-error');
      var i = f.querySelector('input, select');
      if (i) i.removeAttribute('aria-invalid');
    });
  }
  function validateEmail(input) {
    var v = input.value.trim();
    if (!v) { setFieldError(input, 'Enter your email address.'); return false; }
    if (!EMAIL_RE.test(v)) { setFieldError(input, 'That email address does not look right.'); return false; }
    setFieldError(input, '');
    return true;
  }
  function validateRequired(input, message) {
    if (!input.value.trim()) { setFieldError(input, message || 'This field is required.'); return false; }
    setFieldError(input, '');
    return true;
  }

  /* --------------------------------------------------------------- auth --- */
  var FALLBACK_SALT = 'must-portal-v1';

  function fallbackHash(text) {
    // Only used when SubtleCrypto is unavailable (e.g. opened over file://).
    var h1 = 0x811c9dc5, h2 = 0xc2b2ae35;
    var s = FALLBACK_SALT + '|' + text;
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      h1 = (h1 ^ c) * 0x01000193 >>> 0;
      h2 = (h2 + c * 31) >>> 0;
    }
    return 'fnv1a$' + h1.toString(16).padStart(8, '0') + h2.toString(16).padStart(8, '0');
  }

  function hashPassword(password) {
    if (window.crypto && window.crypto.subtle && window.isSecureContext) {
      var data = new TextEncoder().encode(FALLBACK_SALT + '|' + password);
      return window.crypto.subtle.digest('SHA-256', data).then(function (buf) {
        return 'sha256$' + Array.prototype.map.call(new Uint8Array(buf), function (b) {
          return b.toString(16).padStart(2, '0');
        }).join('');
      }).catch(function () { return fallbackHash(password); });
    }
    return Promise.resolve(fallbackHash(password));
  }

  function getUser() { return store.get(KEYS.user, null); }
  function setUser(user) { return store.set(KEYS.user, user); }
  function currentSession() { return store.get(KEYS.session, null); }
  function signOut() { store.del(KEYS.session); }

  function makeAppNumber() {
    var year = new Date().getFullYear() + 1;
    var n = String(Math.floor(Math.random() * 90000) + 10000);
    return 'MUST/APP/' + year + '/' + n;
  }

  function defaultApplication() {
    return {
      stage: 2,
      docs: { id: false, transcript: false, photo: false, payment: false },
      feePaid: false,
      submitted: false,
      read: [],
      updated: Date.now()
    };
  }

  function ensureDemoUser() {
    var user = getUser();
    if (user && user.email === 'demo@must.ac.ug') return Promise.resolve(user);
    return hashPassword('Must@2026').then(function (hash) {
      var demo = {
        surname: 'Atuhaire',
        given: 'Daniel',
        email: 'demo@must.ac.ug',
        phone: '+256772123456',
        programme: 'BSc Computer Science',
        appNo: 'MUST/APP/' + (new Date().getFullYear() + 1) + '/20481',
        hash: hash,
        createdAt: Date.now()
      };
      setUser(demo);
      if (!store.get(KEYS.app, null)) store.set(KEYS.app, defaultApplication());
      return demo;
    });
  }

  function initials(user) {
    if (!user) return 'MU';
    var a = (user.given || '').trim().charAt(0);
    var b = (user.surname || '').trim().charAt(0);
    return ((a || '') + (b || '')).toUpperCase() || 'MU';
  }
  function fullName(user) {
    if (!user) return 'Applicant';
    return [user.given, user.surname].filter(Boolean).join(' ').trim();
  }

  /* ------------------------------------------------------- shared wiring -- */
  function wirePasswordToggles() {
    $$('[data-toggle-password]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var input = document.getElementById(btn.getAttribute('data-toggle-password'));
        if (!input) return;
        var show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
        btn.setAttribute('aria-pressed', show ? 'true' : 'false');
        var use = btn.querySelector('use');
        if (use) use.setAttribute('href', show ? '#i-eye-off' : '#i-eye');
      });
    });
  }

  function busy(btn, isBusy) {
    if (!btn) return;
    btn.setAttribute('aria-busy', isBusy ? 'true' : 'false');
    btn.disabled = isBusy;
  }

  function redirect(path) { window.location.href = path; }

  /* ------------------------------------------------------------ LOGIN ---- */
  function initLogin() {
    var form = $('#loginForm');
    if (!form) return;
    var email = $('#email');
    var password = $('#password');
    var remember = $('#remember');
    var submit = $('#loginSubmit');
    var note = $('#loginNote');

    var remembered = store.get(KEYS.remember, '');
    if (remembered) { email.value = remembered; if (remember) remember.checked = true; }

    [email, password].forEach(function (input) {
      input.addEventListener('input', function () { setFieldError(input, ''); hideNote(); });
    });

    function showNote(kind, text, link) {
      note.className = 'alert mt-3 alert--' + kind;
      note.innerHTML = '<svg aria-hidden="true"><use href="#i-' + (kind === 'danger' ? 'alert-circle' : 'info') + '"></use></svg><div></div>';
      note.firstElementChild.nextElementSibling.textContent = text;
      if (link) {
        var a = document.createElement('a');
        a.href = 'register.html';
        a.textContent = link;
        a.style.cssText = 'display:inline-block;margin-top:4px;font-weight:700;color:inherit';
        note.lastElementChild.appendChild(document.createElement('br'));
        note.lastElementChild.appendChild(a);
      }
      note.hidden = false;
    }
    function hideNote() { note.hidden = true; }

    $('#demoFill').addEventListener('click', function () {
      ensureDemoUser().then(function () {
        email.value = 'demo@must.ac.ug';
        password.value = 'Must@2026';
        clearFieldErrors(form);
        hideNote();
        toast('Demo credentials ready', 'Press "Sign in" to open the sample dashboard.', 'info');
      });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (submit.getAttribute('aria-busy') === 'true') return;
      clearFieldErrors(form);
      hideNote();

      var okEmail = validateEmail(email);
      var okPass = validateRequired(password, 'Enter your password.');
      if (!okEmail || !okPass) return;

      busy(submit, true);
      var started = Date.now();

      Promise.all([hashPassword(password.value), Promise.resolve(getUser())]).then(function (res) {
        var hash = res[0];
        var user = res[1];
        var wait = Math.max(0, 650 - (Date.now() - started));

        setTimeout(function () {
          busy(submit, false);
          if (!user) {
            showNote('danger', 'No application account uses that email yet.', 'Create an account');
            setFieldError(email, 'We could not find an account for this email.');
            return;
          }
          if (user.email.toLowerCase() !== email.value.trim().toLowerCase()) {
            showNote('danger', 'No application account uses that email yet.', 'Create an account');
            setFieldError(email, 'No account found for this email.');
            return;
          }
          if (hash !== user.hash) {
            setFieldError(password, 'Incorrect password. Try again or reset it below.');
            return;
          }
          store.set(KEYS.session, { email: user.email, at: Date.now() });
          if (remember && remember.checked) store.set(KEYS.remember, user.email);
          else store.del(KEYS.remember);
          if (!store.get(KEYS.app, null)) store.set(KEYS.app, defaultApplication());
          redirect('dashboard.html');
        }, wait);
      });
    });
  }

  /* --------------------------------------------------------- REGISTER ---- */
  function initRegister() {
    var form = $('#registerForm');
    if (!form) return;

    var step1 = $('#step1');
    var step2 = $('#step2');
    var success = $('#registerSuccess');
    var toStep2 = $('#toStep2');
    var backStep = $('#backStep1');
    var submit = $('#registerSubmit');
    var steps = $$('.steps .step');

    var password = $('#password');
    var confirm = $('#confirmPassword');
    var strength = $('#strength');
    var strengthLabel = $('#strengthLabel');

    function goStep(n) {
      step1.hidden = n !== 1;
      step2.hidden = n !== 2;
      steps.forEach(function (s, i) {
        s.classList.toggle('is-active', i === n - 1);
        s.classList.toggle('is-done', i < n - 1);
      });
      var target = n === 1 ? $('#surname') : $('#password');
      if (target) target.focus({ preventScroll: false });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function validateStep1() {
      var ok = true;
      ok = validateRequired($('#surname'), 'Enter your surname.') && ok;
      ok = validateRequired($('#givenNames'), 'Enter your other names.') && ok;
      ok = validateEmail($('#regEmail')) && ok;

      var phone = $('#phone');
      var digits = phone.value.replace(/\D/g, '');
      if (!digits) { setFieldError(phone, 'Enter your phone number.'); ok = false; }
      else if (digits.length < 9) { setFieldError(phone, 'Use a full number, e.g. 772 123 456.'); ok = false; }
      else setFieldError(phone, '');

      var programme = $('#programme');
      if (!programme.value) { setFieldError(programme, 'Choose a programme.'); ok = false; }
      else setFieldError(programme, '');
      return ok;
    }

    function scorePassword(value) {
      var score = 0;
      if (value.length >= 8) score++;
      if (value.length >= 12) score++;
      if (/[A-Z]/.test(value) && /[a-z]/.test(value)) score++;
      if (/\d/.test(value) && /[^A-Za-z0-9]/.test(value)) score++;
      return Math.min(score, 4);
    }
    var LABELS = ['Too short', 'Weak', 'Fair', 'Strong', 'Excellent'];

    password.addEventListener('input', function () {
      var score = scorePassword(password.value);
      strength.setAttribute('data-score', String(score));
      strength.hidden = password.value.length === 0;
      strengthLabel.textContent = LABELS[score];
      setFieldError(password, '');
    });

    window.addEventListener('load', function () {
      $('#surname') && $('#surname').focus();
    });

    toStep2.addEventListener('click', function () {
      clearFieldErrors(step1);
      if (!validateStep1()) {
        var firstError = step1.querySelector('.has-error input, .has-error select');
        if (firstError) firstError.focus();
        return;
      }
      var existing = getUser();
      if (existing && existing.email.toLowerCase() === $('#regEmail').value.trim().toLowerCase()) {
        setFieldError($('#regEmail'), 'An account already uses this email. Sign in instead.');
        return;
      }
      goStep(2);
    });

    backStep.addEventListener('click', function () { goStep(1); });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (submit.getAttribute('aria-busy') === 'true') return;
      clearFieldErrors(step2);

      var ok = true;
      if (password.value.length < 8) { setFieldError(password, 'Use at least 8 characters.'); ok = false; }
      else if (!/[A-Za-z]/.test(password.value) || !/\d/.test(password.value)) {
        setFieldError(password, 'Mix letters and numbers for a safer password.'); ok = false;
      }
      if (confirm.value !== password.value) { setFieldError(confirm, 'The two passwords do not match.'); ok = false; }
      if (!$('#terms').checked) { setFieldError($('#terms'), 'Accept the application terms to continue.'); ok = false; }
      if (!ok) return;

      busy(submit, true);
      hashPassword(password.value).then(function (hash) {
        var user = {
          surname: $('#surname').value.trim(),
          given: $('#givenNames').value.trim(),
          email: $('#regEmail').value.trim(),
          phone: $('#countryCode').value + $('#phone').value.replace(/\D/g, '').replace(/^0+/, ''),
          programme: $('#programme').value,
          appNo: makeAppNumber(),
          hash: hash,
          createdAt: Date.now()
        };
        setTimeout(function () {
          busy(submit, false);
          setUser(user);
          store.set(KEYS.app, defaultApplication());
          store.set(KEYS.session, { email: user.email, at: Date.now() });

          $('#successName').textContent = user.given;
          $('#successRef').textContent = user.appNo;
          form.hidden = true;
          success.hidden = false;
          steps.forEach(function (s) { s.classList.add('is-done'); s.classList.remove('is-active'); });
          window.scrollTo({ top: 0, behavior: 'smooth' });
          toast('Account created', 'Your application number is ready.', 'ok');
        }, 650);
      });
    });

    $('#copyRef').addEventListener('click', function () {
      var text = $('#successRef').textContent;
      var done = function () { toast('Copied', 'Application number copied to clipboard.', 'ok'); };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done).catch(fallback);
      } else fallback();
      function fallback() {
        var range = document.createRange();
        range.selectNodeContents($('#successRef'));
        var sel = window.getSelection();
        sel.removeAllRanges(); sel.addRange(range);
        try { document.execCommand('copy'); done(); } catch (e) {}
      }
    });
  }

  /* ------------------------------------------------------------ FORGOT --- */
  function initForgot() {
    var form = $('#forgotForm');
    if (!form) return;

    var stepEmail = $('#fpStep1');
    var stepCode = $('#fpStep2');
    var stepReset = $('#fpStep3');
    var stepDone = $('#fpDone');
    var dots = $$('.steps .step');
    var emailInput = $('#fpEmail');
    var otpInputs = $$('.otp input');
    var timerEl = $('#otpTimer');
    var state = { email: '', code: '', expires: 0, attempts: 0 };

    function go(n) {
      [stepEmail, stepCode, stepReset].forEach(function (s, i) { if (s) s.hidden = i !== n - 1; });
      stepDone.hidden = n !== 4;
      dots.forEach(function (d, i) {
        d.classList.toggle('is-active', i === n - 1 && n < 4);
        d.classList.toggle('is-done', i < n - 1 || n === 4);
      });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function newCode() {
      state.code = String(Math.floor(100000 + Math.random() * 900000));
      state.expires = Date.now() + 5 * 60 * 1000;
      state.attempts = 0;
      $('#demoCode').textContent = state.code;
      otpInputs.forEach(function (i) { i.value = ''; i.removeAttribute('aria-invalid'); });
      $('#otpError').hidden = true;
      $('#otpError').className = 'alert alert--danger mt-3';
      otpInputs[0].focus();
      startTimer();
    }

    var timerId = null;
    function startTimer() {
      clearInterval(timerId);
      function tick() {
        var left = Math.max(0, state.expires - Date.now());
        var m = Math.floor(left / 60000);
        var s = Math.floor((left % 60000) / 1000);
        timerEl.textContent = String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
        if (left === 0) {
          clearInterval(timerId);
          $('#otpError').hidden = false;
          $('#otpError').className = 'alert alert--danger mt-3';
          $('#otpError').lastElementChild.textContent = 'That code expired. Request a new one.';
        }
      }
      tick();
      timerId = setInterval(tick, 1000);
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      clearFieldErrors(stepEmail);
      if (!validateEmail(emailInput)) return;

      var user = getUser();
      if (!user || user.email.toLowerCase() !== emailInput.value.trim().toLowerCase()) {
        setFieldError(emailInput, 'No application account uses this email.');
        $('#fpHelp').hidden = false;
        return;
      }
      state.email = user.email;
      var sent = $('#fpSentTo');
      if (sent) sent.textContent = user.email;
      go(2);
      newCode();
      toast('Recovery code issued', 'This is a demo — the code is shown on screen.', 'info');
    });

    otpInputs.forEach(function (input, idx) {
      input.addEventListener('input', function () {
        input.value = input.value.replace(/\D/g, '').slice(0, 1);
        if (input.value && idx < otpInputs.length - 1) otpInputs[idx + 1].focus();
      });
      input.addEventListener('keydown', function (e) {
        if (e.key === 'Backspace' && !input.value && idx > 0) otpInputs[idx - 1].focus();
        if (e.key === 'ArrowLeft' && idx > 0) otpInputs[idx - 1].focus();
        if (e.key === 'ArrowRight' && idx < otpInputs.length - 1) otpInputs[idx + 1].focus();
      });
      input.addEventListener('paste', function (e) {
        e.preventDefault();
        var text = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, 6);
        otpInputs.forEach(function (box, i) { box.value = text.charAt(i) || ''; });
        if (text) otpInputs[Math.min(text.length, 5)].focus();
      });
    });

    $('#verifyCode').addEventListener('click', function () {
      var entered = otpInputs.map(function (i) { return i.value; }).join('');
      var err = $('#otpError');
      if (Date.now() > state.expires) {
        err.hidden = false; err.className = 'alert alert--danger mt-3';
        err.lastElementChild.textContent = 'That code expired. Request a new one.';
        return;
      }
      if (entered.length !== 6) {
        err.hidden = false; err.className = 'alert alert--danger mt-3';
        err.lastElementChild.textContent = 'Enter all six digits.';
        return;
      }
      if (entered !== state.code) {
        state.attempts++;
        err.hidden = false; err.className = 'alert alert--danger mt-3';
        err.lastElementChild.textContent = 'That code does not match. Check it and try again.';
        otpInputs.forEach(function (i) { i.setAttribute('aria-invalid', 'true'); });
        return;
      }
      clearInterval(timerId);
      go(3);
      $('#newPassword').focus();
    });

    $('#resendCode').addEventListener('click', function () {
      newCode();
      toast('New code issued', 'The previous code no longer works.', 'info');
    });

    var newPassword = $('#newPassword');
    var confirmPassword = $('#confirmPassword2');

    function score(value) {
      var s = 0;
      if (value.length >= 8) s++;
      if (value.length >= 12) s++;
      if (/[A-Z]/.test(value) && /[a-z]/.test(value)) s++;
      if (/\d/.test(value) && /[^A-Za-z0-9]/.test(value)) s++;
      return Math.min(s, 4);
    }
    newPassword.addEventListener('input', function () {
      var bar = $('#resetStrength');
      bar.setAttribute('data-score', String(score(newPassword.value)));
      bar.hidden = newPassword.value.length === 0;
      setFieldError(newPassword, '');
    });

    $('#resetSubmit').addEventListener('click', function (e) {
      e.preventDefault();
      var btn = e.currentTarget;
      clearFieldErrors(stepReset);
      var ok = true;
      if (newPassword.value.length < 8) { setFieldError(newPassword, 'Use at least 8 characters.'); ok = false; }
      else if (!/[A-Za-z]/.test(newPassword.value) || !/\d/.test(newPassword.value)) {
        setFieldError(newPassword, 'Mix letters and numbers for a safer password.'); ok = false;
      }
      if (confirmPassword.value !== newPassword.value) { setFieldError(confirmPassword, 'The two passwords do not match.'); ok = false; }
      if (!ok) return;

      busy(btn, true);
      hashPassword(newPassword.value).then(function (hash) {
        var user = getUser();
        if (user) { user.hash = hash; setUser(user); }
        setTimeout(function () {
          busy(btn, false);
          go(4);
          toast('Password updated', 'Sign in with your new password.', 'ok');
        }, 550);
      });
    });
  }

  /* -------------------------------------------------------------- boot --- */
  function boot() {
    wirePasswordToggles();
    var page = document.body.getAttribute('data-page');
    if (page === 'login') initLogin();
    if (page === 'register') initRegister();
    if (page === 'forgot') initForgot();

    // If a session already exists, the sign-in page offers a shortcut instead of
    // silently bouncing the user around.
    if (page === 'login' && currentSession()) {
      var user = getUser();
      var note = $('#sessionNote');
      if (note && user) {
        note.hidden = false;
        $('#sessionName').textContent = fullName(user);
      }
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  window.MUST = {
    store: store, toast: toast, KEYS: KEYS,
    getUser: getUser, setUser: setUser, session: currentSession, signOut: signOut,
    hashPassword: hashPassword, fullName: fullName, initials: initials,
    toggleTheme: toggleTheme, applyTheme: applyTheme,
    setFieldError: setFieldError, validateEmail: validateEmail
  };
})();
