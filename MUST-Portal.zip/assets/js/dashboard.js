/* MUST Portal — application dashboard logic.
   All state lives in localStorage under `must.app`; this is a front-end demo. */
(function () {
  'use strict';

  var M = window.MUST;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  var user = M.getUser();
  var session = M.session();

  if (!session || !user) {
    window.location.replace('index.html');
    return;
  }

  var app = M.store.get(M.KEYS.app, null) || {
    stage: 2,
    docs: { id: false, olevel: false, alevel: false, photo: false },
    feePaid: false,
    submitted: false,
    read: [],
    updated: Date.now()
  };
  if (!app.docs) app.docs = { id: false, olevel: false, alevel: false, photo: false };

  var DOC_LIST = [
    { key: 'id', name: 'National ID or passport', meta: 'Scanned copy, both sides — PDF or JPG', icon: 'id-card' },
    { key: 'olevel', name: 'O-Level certificate', meta: 'UCE result slip or certificate', icon: 'file-text' },
    { key: 'alevel', name: 'A-Level certificate', meta: 'UACE result slip or certificate', icon: 'file-text' },
    { key: 'photo', name: 'Passport photograph', meta: 'Plain background, taken in the last 6 months', icon: 'user' }
  ];

  var MESSAGES = [
    {
      id: 'm1', title: 'Applications for the 2027/2028 intake are open',
      body: 'The portal closes on 26 February 2027 at 23:59 EAT. Submit before the deadline — late applications are not reviewed.',
      time: '2 days ago', tag: 'Admissions'
    },
    {
      id: 'm2', title: 'Upload clear scans, not phone photos of screens',
      body: 'Blurred or cropped documents delay verification by up to two weeks. Each file must be under 2 MB.',
      time: '5 days ago', tag: 'Documents'
    },
    {
      id: 'm3', title: 'Application fee: UGX 50,000',
      body: 'Pay only through the portal. Keep the receipt number — you will need it on the day you report.',
      time: '1 week ago', tag: 'Finance'
    }
  ];

  var DEADLINE = new Date('2027-02-26T23:59:59+03:00');
  var SECTION_TITLES = {
    overview: 'Overview',
    application: 'My application',
    documents: 'Documents',
    payment: 'Application fee',
    messages: 'Messages',
    profile: 'Profile'
  };

  function save() {
    app.updated = Date.now();
    M.store.set(M.KEYS.app, app);
  }

  function docDone() {
    return DOC_LIST.filter(function (d) { return app.docs[d.key]; }).length;
  }

  function progress() {
    var p = 20;
    if (app.stage >= 3) p += 10;
    p += Math.round((docDone() / DOC_LIST.length) * 30);
    if (app.feePaid) p += 25;
    if (app.submitted) p += 15;
    return Math.min(100, p);
  }

  function stages() {
    var allDocs = docDone() === DOC_LIST.length;
    return [
      { n: 1, name: 'Account created', note: 'Application number issued', done: true },
      { n: 2, name: 'Personal details', note: 'Name, contacts and programme', done: app.stage >= 3 },
      { n: 3, name: 'Documents', note: docDone() + ' of ' + DOC_LIST.length + ' uploaded', done: allDocs },
      { n: 4, name: 'Application fee', note: app.feePaid ? 'UGX 50,000 received' : 'UGX 50,000 outstanding', done: app.feePaid },
      { n: 5, name: 'Review and submit', note: app.submitted ? 'Submitted to admissions' : 'Final step before review', done: app.submitted }
    ];
  }

  function nextAction() {
    var list = stages();
    var current = list.filter(function (s) { return !s.done; })[0];
    if (!current) return { label: 'Application complete', run: function () {}, done: true };
    if (current.n === 2) {
      return {
        label: 'Confirm personal details',
        run: function () {
          app.stage = 3;
          save();
          M.toast('Details confirmed', 'Now upload your four supporting documents.', 'ok');
          render();
        }
      };
    }
    if (current.n === 3) {
      return {
        label: 'Upload documents',
        run: function () { go('documents'); M.toast('Upload queue open', 'Mark each document once it is attached.', 'info'); }
      };
    }
    if (current.n === 4) {
      return {
        label: 'Pay application fee',
        run: function () { go('payment'); }
      };
    }
    return {
      label: 'Submit application',
      run: function () {
        app.submitted = true;
        app.stage = 5;
        save();
        render();
        M.toast('Application submitted', 'Admissions will review it within 10 working days.', 'ok');
      }
    };
  }

  /* ------------------------------------------------------------- render --- */
  function render() {
    var pct = progress();
    $('#heroPct').textContent = pct + '%';
    var ring = $('#ringBar');
    if (ring) {
      var r = 56;
      var c = 2 * Math.PI * r;
      ring.style.strokeDasharray = c.toFixed(1);
      ring.style.strokeDashoffset = (c * (1 - pct / 100)).toFixed(1);
    }

    $('#heroGreeting').textContent = greeting() + ', ' + (user.given || 'applicant');
    $('#heroStatus').textContent = app.submitted
      ? 'Submitted — under review by the admissions office.'
      : 'Your application is ' + pct + '% complete. ' + (pct < 100 ? 'Keep going — the next step is short.' : 'Everything is in place.');
    $('#heroRefNo').textContent = user.appNo || '—';
    $('#railName').textContent = M.fullName(user);
    $('#railProg').textContent = user.appNo || 'Applicant';
    $('#avatarBtn').textContent = M.initials(user);
    $('#railAvatar').textContent = M.initials(user);

    var days = Math.ceil((DEADLINE - Date.now()) / 86400000);
    $('#deadlineDays').textContent = days > 0 ? days + ' days' : 'closed';
    $('#deadlineText').textContent = days > 0
      ? 'Intake closes 26 February 2027'
      : 'The intake window has closed';

    // tracker
    var host = $('#tracker');
    var list = stages();
    var firstOpen = list.filter(function (s) { return !s.done; })[0];
    host.innerHTML = list.map(function (s) {
      var cls = s.done ? 'is-done' : (firstOpen && firstOpen.n === s.n ? 'is-current' : 'is-locked');
      return '<li class="track ' + cls + '">' +
        '<span class="track__dot"><svg aria-hidden="true"><use href="#i-' + (s.done ? 'check' : s.n === 5 ? 'flag' : 'circle') + '"></use></svg></span>' +
        '<div class="track__body"><b>' + s.name + '</b><span>' + s.note + '</span>' +
        (firstOpen && firstOpen.n === s.n ? '<span class="mono">You are here</span>' : '') +
        '</div></li>';
    }).join('');

    var action = nextAction();
    var nextBtn = $('#nextAction');
    nextBtn.querySelector('.btn__label').textContent = action.label;
    nextBtn.disabled = !!action.done;

    // summary panel
    $('#statDocs').textContent = docDone() + '/' + DOC_LIST.length;
    $('#statFee').textContent = app.feePaid ? 'Paid' : 'Due';
    $('#statStage').textContent = firstOpen ? String(firstOpen.n) + '/5' : '5/5';

    var unread = MESSAGES.filter(function (m) { return app.read.indexOf(m.id) === -1; }).length;
    $('#msgBadge').textContent = unread;
    $('#msgBadge').hidden = unread === 0;
    $('#bellDot').hidden = unread === 0;
    $('#notifUnread').textContent = unread ? unread + ' unread' : 'All read';

    // documents
    var docHost = $('#docList');
    docHost.innerHTML = DOC_LIST.map(function (d) {
      var done = !!app.docs[d.key];
      return '<li class="row doc ' + (done ? 'is-done' : '') + '" data-searchable>' +
        '<span class="row__icon"><svg aria-hidden="true"><use href="#i-' + (done ? 'check' : d.icon) + '"></use></svg></span>' +
        '<div class="row__body"><b>' + d.name + '</b><span>' + d.meta + '</span></div>' +
        '<div class="row__end">' +
        '<span class="pill ' + (done ? 'pill--ok' : '') + '">' + (done ? 'Attached' : 'Pending') + '</span>' +
        '<button class="btn btn--ghost btn--sm" data-doc="' + d.key + '" aria-label="' + (done ? 'Remove' : 'Attach') + ' ' + d.name + '">' +
        (done ? 'Remove' : 'Attach') + '</button></div></li>';
    }).join('');
    $('#docCount').textContent = docDone() + ' of ' + DOC_LIST.length;

    // fee
    $('#feeStatus').textContent = app.feePaid ? 'Paid' : 'Outstanding';
    $('#feeStatus').className = 'pill ' + (app.feePaid ? 'pill--ok' : 'pill--gold');
    $('#feeAction').hidden = app.feePaid;
    $('#feeReceipt').hidden = !app.feePaid;
    $('#feeReceiptNo').textContent = 'MUST/FEE/' + (user.appNo || '').split('/').pop();

    // messages
    var msgHost = $('#messageList');
    msgHost.innerHTML = MESSAGES.map(function (m) {
      var unreadItem = app.read.indexOf(m.id) === -1;
      return '<li class="msg ' + (unreadItem ? 'is-unread' : '') + '" data-msg="' + m.id + '" data-searchable tabindex="0" role="button" aria-label="' + (unreadItem ? 'Unread: ' : '') + m.title + '">' +
        '<span class="msg__dot" aria-hidden="true"></span>' +
        '<div class="msg__body"><b>' + m.title + '</b><p>' + m.body + '</p>' +
        '<span class="msg__meta">' + m.tag + ' · ' + m.time + '</span></div></li>';
    }).join('');

    // profile
    $('#pfName').textContent = [user.given, user.surname].join(' ');
    $('#pfEmail').textContent = user.email;
    $('#pfPhone').textContent = user.phone || '—';
    $('#pfProgramme').textContent = user.programme || '—';
    $('#pfRef').textContent = user.appNo || '—';
    $('#pfCreated').textContent = new Date(user.createdAt || Date.now()).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });

    // application detail panel
    $('#appSurname').value = user.surname || '';
    $('#appGiven').value = user.given || '';
    $('#appEmail').value = user.email || '';
    $('#appPhone').value = user.phone || '';
    $('#appProgramme').value = user.programme || '';
  }

  function greeting() {
    var h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  }

  /* --------------------------------------------------------------- nav --- */
  function go(section, push) {
    if (!SECTION_TITLES[section]) section = 'overview';
    $$('.section').forEach(function (s) { s.classList.toggle('is-active', s.id === 'sec-' + section); });
    $$('.nav-item[data-section]').forEach(function (b) {
      var on = b.getAttribute('data-section') === section;
      b.classList.toggle('is-active', on);
      if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
    $('#topTitle').textContent = SECTION_TITLES[section];
    var search = $('#search');
    if (search && search.value) {
      search.value = '';
      $$('[data-searchable]').forEach(function (item) { item.classList.remove('hide'); });
      var empty = $('#searchEmpty');
      if (empty) empty.hidden = true;
    }
    if (push !== false && history.replaceState) history.replaceState(null, '', '#' + section);
    document.title = SECTION_TITLES[section] + ' · MUST Portal';
    closeDrawer();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function openDrawer() {
    $('#rail').classList.add('is-open');
    $('#scrim').classList.add('is-on');
    $('#menuBtn').setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  }
  function closeDrawer() {
    $('#rail').classList.remove('is-open');
    $('#scrim').classList.remove('is-on');
    $('#menuBtn').setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  }

  /* ------------------------------------------------------------- events -- */
  function boot() {
    render();
    var start = (location.hash || '').replace('#', '');
    go(SECTION_TITLES[start] ? start : 'overview', false);

    $$('[data-section]').forEach(function (b) {
      b.addEventListener('click', function () { go(b.getAttribute('data-section')); });
    });

    window.addEventListener('hashchange', function () {
      var s = (location.hash || '').replace('#', '');
      if (SECTION_TITLES[s]) go(s, false);
    });

    $('#menuBtn').addEventListener('click', function () {
      if ($('#rail').classList.contains('is-open')) closeDrawer(); else openDrawer();
    });
    $('#scrim').addEventListener('click', closeDrawer);

    $('#nextAction').addEventListener('click', function () { nextAction().run(); });

    $('#docList').addEventListener('click', function (e) {
      var btn = e.target.closest('[data-doc]');
      if (!btn) return;
      var key = btn.getAttribute('data-doc');
      app.docs[key] = !app.docs[key];
      save();
      render();
      var doc = DOC_LIST.filter(function (d) { return d.key === key; })[0];
      M.toast(app.docs[key] ? 'Document attached' : 'Document removed', doc.name + (app.docs[key] ? ' is now in your file.' : ' was removed from your file.'), app.docs[key] ? 'ok' : 'warn');
    });

    $('#feeAction').addEventListener('click', function () {
      var btn = this;
      btn.setAttribute('aria-busy', 'true');
      setTimeout(function () {
        btn.setAttribute('aria-busy', 'false');
        app.feePaid = true;
        app.stage = Math.max(app.stage, 4);
        save();
        render();
        M.toast('Payment recorded', 'A receipt number has been added to your file.', 'ok');
      }, 900);
    });

    $('#messageList').addEventListener('click', function (e) {
      var item = e.target.closest('[data-msg]');
      if (!item) return;
      var id = item.getAttribute('data-msg');
      if (app.read.indexOf(id) === -1) {
        app.read.push(id);
        save();
        render();
      }
      item.classList.toggle('is-open');
    });
    $('#messageList').addEventListener('keydown', function (e) {
      if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('[data-msg]')) {
        e.preventDefault();
        e.target.click();
      }
    });

    $('#markAllRead').addEventListener('click', function () {
      app.read = MESSAGES.map(function (m) { return m.id; });
      save();
      render();
      M.toast('Inbox cleared', 'All messages marked as read.', 'ok');
    });

    $('#profileForm').addEventListener('submit', function (e) {
      e.preventDefault();
      if (!M.validateEmail($('#profileEmail'))) return;
      user.given = $('#profileGiven').value.trim() || user.given;
      user.surname = $('#profileSurname').value.trim() || user.surname;
      user.email = $('#profileEmail').value.trim();
      user.phone = $('#profilePhone').value.trim();
      M.setUser(user);
      render();
      M.toast('Profile saved', 'Your details were updated on this device.', 'ok');
    });

    $('#appForm').addEventListener('submit', function (e) {
      e.preventDefault();
      user.surname = $('#appSurname').value.trim();
      user.given = $('#appGiven').value.trim();
      user.phone = $('#appPhone').value.trim();
      user.programme = $('#appProgramme').value;
      M.setUser(user);
      render();
      M.toast('Details saved', 'Admissions sees the updated version.', 'ok');
    });

    $('#copyAppNo').addEventListener('click', function () {
      var text = user.appNo || '';
      var ok = function () { M.toast('Copied', 'Application number copied.', 'ok'); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(ok).catch(ok);
      else ok();
    });

    $('#themeBtn').addEventListener('click', function () {
      var next = M.toggleTheme();
      $('#themeIcon').setAttribute('href', next === 'dark' ? '#i-sun' : '#i-moon');
      this.setAttribute('aria-label', next === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
    });
    $('#themeIcon').setAttribute('href', document.documentElement.getAttribute('data-theme') === 'dark' ? '#i-sun' : '#i-moon');

    var pop = $('#notifPop');
    $('#bellBtn').addEventListener('click', function (e) {
      e.stopPropagation();
      var open = pop.classList.toggle('is-open');
      this.setAttribute('aria-expanded', open ? 'true' : 'false');
      if (open) $('#notifList').innerHTML = MESSAGES.slice(0, 3).map(function (m) {
        return '<div class="pop__item"><b>' + m.title + '</b><span>' + m.tag + ' · ' + m.time + '</span></div>';
      }).join('');
    });
    document.addEventListener('click', function (e) {
      if (!pop.contains(e.target) && e.target.closest('#bellBtn') === null) {
        pop.classList.remove('is-open');
        $('#bellBtn').setAttribute('aria-expanded', 'false');
      }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { closeDrawer(); pop.classList.remove('is-open'); }
    });

    $('#signOut').addEventListener('click', function () {
      M.signOut();
      window.location.href = 'index.html?signedout=1';
    });

    // search filters whatever is on screen
    var search = $('#search');
    search.addEventListener('input', function () {
      var q = search.value.trim().toLowerCase();
      var active = $('.section.is-active');
      if (!active) return;
      var items = $$('[data-searchable]', active);
      var shown = 0;
      items.forEach(function (item) {
        var match = !q || item.textContent.toLowerCase().indexOf(q) !== -1;
        item.classList.toggle('hide', !match);
        if (match) shown++;
      });
      var none = $('#searchEmpty', active) || $('#searchEmpty');
      if (none) none.hidden = !(q && items.length && shown === 0);
    });

    $('#printBtn').addEventListener('click', function () { window.print(); });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
